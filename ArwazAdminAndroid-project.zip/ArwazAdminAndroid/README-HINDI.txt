ARWAZ ADMIN ANDROID PROJECT

Yeh Android Studio project hai jo Arwaz Admin web panel ko alag Android app (WebView wrapper) mein kholta hai.
App URL: https://roaring-horse-287fd9.netlify.app/admin.html

ZAROORI:
- Is environment mein Android SDK/Gradle build tools maujood nahi hain, isliye yahan seedha APK compile nahi ho saka.
- APK banane ke liye project ko GitHub par upload karke Actions tab mein 'Build Arwaz Admin APK' workflow ko Run workflow karein. Build complete hone par Artifacts se APK download hoti hai.
- App ke liye internet zaroori hai.
- Admin login Firebase Authentication par depend karta hai.
- Firebase Storage upgrade required hone ke kaaran photo/video upload tab tak kaam nahi karega jab tak storage ka supported plan/configuration na ho.
